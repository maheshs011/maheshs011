package com.mphasis.employee_payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "Admin_Registration")
@Entity
public class AdminRegistration {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private long id;

	@Column(name = "Employee_name")
	private String Employee_name;

	@Column(name = "Designation")
	private String Designation;

	@Column(name = "Email")
	private String Email;

	@Column(name = "password")
	private String password;

	public AdminRegistration() {

	}

	public AdminRegistration(long Id, String employee_name, String designation, String email, String password) {
		super();
		Id = id;
		Employee_name = employee_name;
		Designation = designation;
		Email = email;
		this.password = password;
	}

	public long getid() {
		return id;
	}

	public void setid(long Id) {
		Id = id;
	}

	public String getEmployee_name() {
		return Employee_name;
	}

	public void setEmployee_name(String employee_name) {
		Employee_name = employee_name;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}