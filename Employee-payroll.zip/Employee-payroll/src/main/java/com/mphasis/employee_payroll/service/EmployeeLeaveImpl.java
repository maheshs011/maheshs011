package com.mphasis.employee_payroll.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mphasis.employee_payroll.model.EmployeeLeave;
import com.mphasis.employee_payroll.repository.EmployeeLeaveRepository;

@Service
public class EmployeeLeaveImpl implements EmployeeLeaveService {

	private EmployeeLeaveRepository employeeLeaveRepository;

	public EmployeeLeaveImpl(EmployeeLeaveRepository employeeLeaveRepository) {
		super();
		this.employeeLeaveRepository = employeeLeaveRepository;
	}

	@Override
	public EmployeeLeave saveEmployeeLeave(EmployeeLeave employeeLeave) {
		return employeeLeaveRepository.save(employeeLeave);
	}

	@Override
	public List<EmployeeLeave> getAllLeave() {
		return employeeLeaveRepository.findAll();
	}

}