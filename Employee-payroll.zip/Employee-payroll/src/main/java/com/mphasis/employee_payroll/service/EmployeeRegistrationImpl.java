package com.mphasis.employee_payroll.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mphasis.employee_payroll.exception.ResourceNotFoundException;
import com.mphasis.employee_payroll.model.EmployeeRegistration;
import com.mphasis.employee_payroll.repository.EmployeeRegistrationRepository;

@Service
public class EmployeeRegistrationImpl implements EmployeeRegistrationService {

	private EmployeeRegistrationRepository employeeRegistrationRepository;

	public EmployeeRegistrationImpl(EmployeeRegistrationRepository employeeRegistrationRepository) {
		super();
		this.employeeRegistrationRepository = employeeRegistrationRepository;
	}

	@Override
	public EmployeeRegistration saveEmployeeRegistration(EmployeeRegistration employeeRegistration) {
		return employeeRegistrationRepository.save(employeeRegistration);
	}

	@Override
	public List<EmployeeRegistration> getAllEmployee() {
		return employeeRegistrationRepository.findAll();
	}

	@Override
	public EmployeeRegistration getEmployeeRegistrationById(long id) {
		return employeeRegistrationRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee", "Id", id));

	}

}