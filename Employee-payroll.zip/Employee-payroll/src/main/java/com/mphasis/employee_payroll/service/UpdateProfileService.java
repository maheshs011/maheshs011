package com.mphasis.employee_payroll.service;

import com.mphasis.employee_payroll.model.UpdateProfile;

public interface UpdateProfileService {

	UpdateProfile updateProfile(UpdateProfile updateProfile, long id);

}