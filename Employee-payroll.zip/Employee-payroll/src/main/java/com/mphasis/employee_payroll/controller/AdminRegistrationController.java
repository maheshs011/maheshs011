package com.mphasis.employee_payroll.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.employee_payroll.model.AdminRegistration;
import com.mphasis.employee_payroll.service.AdminRegistrationService;

@RestController
@RequestMapping("/api/v1")
public class AdminRegistrationController {

	private AdminRegistrationService adminRegistrationService;

	public AdminRegistrationController(AdminRegistrationService adminRegistrationService) {
		super();
		this.adminRegistrationService = adminRegistrationService;
	}

	@PostMapping("/addAdmin")
	public ResponseEntity<AdminRegistration> saveAdminRegistration(@RequestBody AdminRegistration adminRegistration) {
		return new ResponseEntity<AdminRegistration>(adminRegistrationService.saveAdminRegistration(adminRegistration),
				HttpStatus.CREATED);
	}

	@GetMapping("/viewAdmins")
	public List<AdminRegistration> getAllAdmins() {
		return adminRegistrationService.getAllAdmins();
	}

	@GetMapping("/getAdmin/{id}")
	public ResponseEntity<AdminRegistration> getAdminById(@PathVariable("id") long employeeId) {
		return new ResponseEntity<AdminRegistration>(adminRegistrationService.getAdminRegistrationById(employeeId),
				HttpStatus.OK);
	}

	@PutMapping("/updateAdmin/{id}")
	public ResponseEntity<AdminRegistration> updateAdmin(@PathVariable("id") long id,
			@RequestBody AdminRegistration adminRegistration) {
		return new ResponseEntity<AdminRegistration>(
				adminRegistrationService.updateAdminRegistration(adminRegistration, id), HttpStatus.OK);
	}

	@DeleteMapping("/deleteAdmin/{id}")
	public ResponseEntity<String> deleteAdminRegistration(@PathVariable("id") long id) {

		adminRegistrationService.deleteAdminRegistration(id);

		return new ResponseEntity<String>("Admin deleted successfully!.", HttpStatus.OK);
	}

}