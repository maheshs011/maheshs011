package com.mphasis.employee_payroll.service;

import java.util.List;

import com.mphasis.employee_payroll.model.AdminRegistration;


public interface AdminRegistrationService {
	AdminRegistration saveAdminRegistration(AdminRegistration adminRegistration);

	List<AdminRegistration> getAllAdmins();

	AdminRegistration getAdminRegistrationById(long id);

	AdminRegistration updateAdminRegistration(AdminRegistration adminRegistration, long id);

	void deleteAdminRegistration(long id);
}