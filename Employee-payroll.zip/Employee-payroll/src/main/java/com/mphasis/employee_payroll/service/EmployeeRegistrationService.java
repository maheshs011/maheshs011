package com.mphasis.employee_payroll.service;

import java.util.List;

import com.mphasis.employee_payroll.model.EmployeeRegistration;


public interface EmployeeRegistrationService {
	EmployeeRegistration saveEmployeeRegistration(EmployeeRegistration employeeRegistration);

	List<EmployeeRegistration> getAllEmployee();

	EmployeeRegistration getEmployeeRegistrationById(long id);

}