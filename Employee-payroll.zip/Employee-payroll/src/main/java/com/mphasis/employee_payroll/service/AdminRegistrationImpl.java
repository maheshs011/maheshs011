package com.mphasis.employee_payroll.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mphasis.employee_payroll.exception.ResourceNotFoundException;
import com.mphasis.employee_payroll.model.AdminRegistration;
import com.mphasis.employee_payroll.repository.AdminRegistrationRepository;

@Service
public class AdminRegistrationImpl implements AdminRegistrationService {

	private AdminRegistrationRepository adminRegistrationRepository;

	public AdminRegistrationImpl(AdminRegistrationRepository adminRegistrationRepository) {
		super();
		this.adminRegistrationRepository = adminRegistrationRepository;
	}

	@Override
	public AdminRegistration saveAdminRegistration(AdminRegistration adminRegistration) {
		return adminRegistrationRepository.save(adminRegistration);
	}

	@Override
	public List<AdminRegistration> getAllAdmins() {
		return adminRegistrationRepository.findAll();
	}

	@Override
	public AdminRegistration getAdminRegistrationById(long id) {
		return adminRegistrationRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Admin", "Id", id));

	}

	@Override
	public AdminRegistration updateAdminRegistration(AdminRegistration adminRegistration, long id) {

		AdminRegistration adminRegistrationDetails = adminRegistrationRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Admin", "Id", id));

		adminRegistrationDetails.setEmployee_name(adminRegistration.getEmployee_name());
		adminRegistrationDetails.setDesignation(adminRegistration.getDesignation());
		adminRegistrationDetails.setEmail(adminRegistration.getEmail());
		adminRegistrationDetails.setPassword(adminRegistration.getPassword());

		adminRegistrationRepository.save(adminRegistrationDetails);
		return adminRegistrationDetails;
	}

	@Override
	public void deleteAdminRegistration(long id) {

		adminRegistrationRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Admin", "Id", id));
		adminRegistrationRepository.deleteById(id);
	}

}